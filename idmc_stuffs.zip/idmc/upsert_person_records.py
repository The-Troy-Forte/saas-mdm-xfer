"""
upsert_person_records.py
------------------------
Reads person data records from YAML and performs inserts/updates
against Informatica MDM SaaS person business entities via REST API.

Supports:
  - Insert new person records into a source system staging area
  - Update existing records (matched by cross-reference key)
  - Bulk operations with configurable batch size
  - Per-record error handling — failed records logged, others continue
  - Dry-run mode

Person types supported: member, provider, employee, broker, employer

Usage:
  python upsert_person_records.py --config records/members.yaml
  python upsert_person_records.py --config records/ --source FACETS_MBR
  python upsert_person_records.py --config records/ --dry-run
  python upsert_person_records.py --config records/ --batch-size 50

YAML schema (see examples/person_records.yaml):
  source_system: FACETS_MBR
  person_type: member
  records:
    - source_id: MBR-001234
      firstName: Jane
      lastName: Smith
      dateOfBirth: "1985-06-15"
      nationalId: "123-45-6789"
      gender: F
      emailAddress: jane.smith@example.com
      phone: "612-555-0100"
      address:
        line1: 123 Main St
        city: Minneapolis
        state: MN
        postalCode: "55401"
"""

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from idmc_client import IDMCClient, IDMCError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# IDMC MDM REST endpoints
PERSON_ENTITY_BASE = "/mds/rest/v1/entity/Person"
PERSON_SEARCH = "/mds/rest/v1/entity/Person/search"
XREF_LOOKUP = "/mds/rest/v1/xref/{source_code}/{source_id}"
BULK_LOAD = "/mds/rest/v1/entity/Person/bulk"


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------
def load_yaml_files(config_path: str, source_filter: Optional[str] = None) -> List[Dict]:
    path = Path(config_path)
    files = sorted(path.glob("*.yaml")) + sorted(path.glob("*.yml")) \
        if path.is_dir() else [path]
    configs = []
    for f in files:
        with open(f) as fh:
            data = yaml.safe_load(fh)
            if not data:
                continue
            if source_filter and data.get("source_system") != source_filter:
                continue
            data["_source_file"] = str(f)
            configs.append(data)
    total = sum(len(c.get("records", [])) for c in configs)
    logger.info("Loaded %d file(s), %d total records", len(configs), total)
    return configs


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
REQUIRED_PERSON_FIELDS = {"source_id", "firstName", "lastName"}

def validate_record(record: Dict) -> List[str]:
    errors = []
    missing = REQUIRED_PERSON_FIELDS - set(record.keys())
    if missing:
        errors.append(f"Missing required fields: {missing}")
    dob = record.get("dateOfBirth")
    if dob:
        from datetime import date
        try:
            parsed = date.fromisoformat(str(dob))
            if parsed > date.today():
                errors.append(f"dateOfBirth {dob} is in the future")
            if parsed.year < 1900:
                errors.append(f"dateOfBirth {dob} is before 1900")
        except ValueError:
            errors.append(f"dateOfBirth '{dob}' is not valid ISO format (YYYY-MM-DD)")
    gender = record.get("gender")
    if gender and gender not in ("M", "F", "U", "MALE", "FEMALE", "UNKNOWN"):
        errors.append(f"gender '{gender}' not in accepted values")
    return errors


# ---------------------------------------------------------------------------
# Payload builders
# ---------------------------------------------------------------------------
def build_person_payload(record: Dict, source_system: str, person_type: str) -> Dict:
    """Map YAML record fields to IDMC person business entity payload."""
    payload: Dict[str, Any] = {
        "sourceSystem": source_system,
        "sourceId": str(record["source_id"]),
        "personType": person_type.upper(),
        "firstName": record.get("firstName", ""),
        "lastName": record.get("lastName", ""),
        "middleName": record.get("middleName", ""),
        "dateOfBirth": record.get("dateOfBirth", ""),
        "gender": record.get("gender", ""),
        "nationalId": record.get("nationalId", ""),
        "emailAddress": record.get("emailAddress", ""),
        "phoneNumber": record.get("phone", ""),
    }

    # Address — map nested YAML address object to IDMC postalAddress
    addr = record.get("address", {})
    if addr:
        payload["postalAddress"] = {
            "addressLine1": addr.get("line1", ""),
            "addressLine2": addr.get("line2", ""),
            "city": addr.get("city", ""),
            "stateProvince": addr.get("state", ""),
            "postalCode": str(addr.get("postalCode", "")),
            "country": addr.get("country", "US"),
        }

    # Person-type-specific fields
    if person_type.lower() == "provider":
        payload["npi"] = record.get("npi", "")
        payload["specialty"] = record.get("specialty", "")
        payload["taxonomyCode"] = record.get("taxonomy_code", "")

    if person_type.lower() == "employee":
        payload["employeeId"] = record.get("employee_id", "")
        payload["department"] = record.get("department", "")
        payload["jobTitle"] = record.get("job_title", "")

    if person_type.lower() in ("broker", "agent"):
        payload["licenseNumber"] = record.get("license_number", "")
        payload["npn"] = record.get("npn", "")

    if person_type.lower() in ("employer", "group"):
        payload["taxId"] = record.get("tax_id", "")
        payload["groupId"] = record.get("group_id", "")

    # Strip empty strings to avoid overwriting existing MDM values with blanks
    return {k: v for k, v in payload.items() if v not in ("", None)}


# ---------------------------------------------------------------------------
# XREF lookup — check if record already exists
# ---------------------------------------------------------------------------
def lookup_by_xref(client: IDMCClient, source_code: str,
                   source_id: str) -> Optional[str]:
    """
    Returns the MDM golden record ID if the source record already exists,
    or None if it is new.
    """
    path = XREF_LOOKUP.format(source_code=source_code, source_id=source_id)
    try:
        result = client.get(path)
        return result.get("goldenRecordId") or result.get("mdmId")
    except IDMCError as e:
        if e.status == 404:
            return None
        raise


# ---------------------------------------------------------------------------
# Single record upsert
# ---------------------------------------------------------------------------
def upsert_record(
    client: IDMCClient,
    record: Dict,
    source_system: str,
    person_type: str,
) -> Tuple[str, Optional[str]]:
    """
    Returns (action, golden_record_id) where action is
    'created', 'updated', or 'error'.
    """
    source_id = str(record["source_id"])
    payload = build_person_payload(record, source_system, person_type)

    # Check XREF to determine insert vs update
    golden_id = lookup_by_xref(client, source_system, source_id)

    if golden_id:
        # Update — PUT to the existing golden record
        path = f"{PERSON_ENTITY_BASE}/{golden_id}"
        logger.debug("  Updating person golden_id=%s source_id=%s", golden_id, source_id)
        try:
            result = client.put(path, payload)
            return "updated", golden_id
        except IDMCError as e:
            logger.error("  Update failed for source_id=%s: %s", source_id, e)
            return "error", None
    else:
        # Insert — POST to create a new person record
        logger.debug("  Creating person source_id=%s", source_id)
        try:
            result = client.post(PERSON_ENTITY_BASE, payload)
            new_id = result.get("goldenRecordId") or result.get("mdmId")
            return "created", new_id
        except IDMCError as e:
            logger.error("  Create failed for source_id=%s: %s", source_id, e)
            return "error", None


# ---------------------------------------------------------------------------
# Bulk upsert with batching
# ---------------------------------------------------------------------------
def bulk_upsert(
    client: IDMCClient,
    records: List[Dict],
    source_system: str,
    person_type: str,
    batch_size: int = 100,
) -> Dict[str, int]:
    """
    Process records in batches. Uses IDMC bulk load endpoint when
    available, falls back to individual upserts.
    """
    results = {"created": 0, "updated": 0, "error": 0, "skipped": 0}

    for i in range(0, len(records), batch_size):
        batch = records[i: i + batch_size]
        logger.info(
            "Processing batch %d–%d of %d",
            i + 1, min(i + batch_size, len(records)), len(records)
        )

        for record in batch:
            # Validate record
            errors = validate_record(record)
            if errors:
                logger.warning(
                    "  Skipping source_id=%s — validation: %s",
                    record.get("source_id", "?"), errors
                )
                results["skipped"] += 1
                continue

            action, golden_id = upsert_record(
                client, record, source_system, person_type
            )
            results[action] = results.get(action, 0) + 1

            if action == "created":
                logger.info(
                    "  Created: source_id=%s → golden_id=%s",
                    record.get("source_id"), golden_id
                )
            elif action == "updated":
                logger.info(
                    "  Updated: source_id=%s → golden_id=%s",
                    record.get("source_id"), golden_id
                )

    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Upsert person records into Informatica MDM SaaS from YAML"
    )
    parser.add_argument("--config", required=True,
                        help="Path to YAML file or directory of YAML files")
    parser.add_argument("--source", default=None,
                        help="Filter to a specific source system code")
    parser.add_argument("--batch-size", type=int, default=100,
                        help="Number of records per batch (default: 100)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview changes without writing")
    parser.add_argument("--validate-only", action="store_true",
                        help="Validate YAML schema only")
    parser.add_argument("--base-url", default=os.environ.get("IDMC_BASE_URL"))
    args = parser.parse_args()

    configs = load_yaml_files(args.config, source_filter=args.source)
    if not configs:
        logger.error("No configs found at: %s", args.config)
        sys.exit(1)

    if args.validate_only:
        total_errors = 0
        for cfg in configs:
            source = cfg.get("source_system", "?")
            for rec in cfg.get("records", []):
                errs = validate_record(rec)
                if errs:
                    logger.error(
                        "  [%s] source_id=%s: %s",
                        source, rec.get("source_id", "?"), errs
                    )
                    total_errors += 1
        if total_errors:
            logger.error("%d validation errors found", total_errors)
            sys.exit(1)
        logger.info("All records valid")
        return

    client = IDMCClient(base_url=args.base_url, dry_run=args.dry_run)

    totals = {"created": 0, "updated": 0, "error": 0, "skipped": 0}
    for cfg in configs:
        source_system = cfg.get("source_system", "")
        person_type = cfg.get("person_type", "member")
        records = cfg.get("records", [])

        if not source_system:
            logger.error("Config %s missing 'source_system'", cfg["_source_file"])
            continue
        if not records:
            logger.warning("No records in %s", cfg["_source_file"])
            continue

        logger.info(
            "Processing %d %s records from source=%s",
            len(records), person_type, source_system
        )
        batch_results = bulk_upsert(
            client, records, source_system, person_type, args.batch_size
        )
        for k, v in batch_results.items():
            totals[k] = totals.get(k, 0) + v

    logger.info(
        "Complete — created: %d  updated: %d  skipped: %d  errors: %d",
        totals["created"], totals["updated"], totals["skipped"], totals["error"],
    )
    if totals["error"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()

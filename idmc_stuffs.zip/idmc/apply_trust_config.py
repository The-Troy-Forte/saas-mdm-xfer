"""
apply_trust_config.py
---------------------
Reads field-level trust override definitions from YAML and applies
them to Informatica MDM SaaS source system configurations.

Trust scores control which source system's value wins survivorship
when multiple sources provide conflicting data for the same person.

Usage:
  python apply_trust_config.py --config trust_config/field_trust_overrides.yaml
  python apply_trust_config.py --config trust_config/ --dry-run

YAML schema:
  overrides:
    - source_system: FACETS_MBR
      fields:
        - mdm_field: emailAddress
          trust: 80
          null_handling: PRESERVE
        - mdm_field: postalAddress.line1
          trust: 75
          null_handling: PRESERVE
    - source_system: SALESFORCE_HC
      fields:
        - mdm_field: emailAddress
          trust: 85
          null_handling: OVERWRITE
"""

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Dict, List

import yaml

from idmc_client import IDMCClient, IDMCError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

FIELD_TRUST_PATH = "/mds/rest/v1/sourceSystem/{code}/fieldTrust"
NULL_HANDLING_VALUES = {"PRESERVE", "OVERWRITE", "OVERWRITE_IF_BLANK"}


def load_yaml_files(config_path: str) -> List[Dict]:
    path = Path(config_path)
    files = sorted(path.glob("*.yaml")) + sorted(path.glob("*.yml")) \
        if path.is_dir() else [path]
    configs = []
    for f in files:
        with open(f) as fh:
            data = yaml.safe_load(fh)
            if data:
                configs.append(data)
    return configs


def validate_config(config: Dict) -> List[str]:
    errors = []
    for override in config.get("overrides", []):
        if "source_system" not in override:
            errors.append("Override missing 'source_system'")
        for field in override.get("fields", []):
            if "mdm_field" not in field:
                errors.append(f"Field entry missing 'mdm_field': {field}")
            trust = field.get("trust")
            if trust is not None and not (0 <= int(trust) <= 100):
                errors.append(f"Trust {trust} out of range 0–100")
            nh = field.get("null_handling", "PRESERVE")
            if nh not in NULL_HANDLING_VALUES:
                errors.append(
                    f"null_handling '{nh}' invalid — must be one of {NULL_HANDLING_VALUES}"
                )
    return errors


def apply_trust_overrides(client: IDMCClient, config: Dict) -> Dict[str, int]:
    results = {"applied": 0, "error": 0}
    for override in config.get("overrides", []):
        code = override["source_system"]
        fields = override.get("fields", [])
        if not fields:
            continue

        payload = {
            "fields": [
                {
                    "fieldName": f["mdm_field"],
                    "trustScore": int(f.get("trust", 80)),
                    "nullHandling": f.get("null_handling", "PRESERVE"),
                }
                for f in fields
            ]
        }

        logger.info(
            "Applying %d trust overrides for source system: %s",
            len(fields), code
        )
        try:
            client.put(FIELD_TRUST_PATH.format(code=code), payload)
            results["applied"] += len(fields)
        except IDMCError as e:
            logger.error("Failed to apply trust overrides for %s: %s", code, e)
            results["error"] += 1

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Apply field-level trust overrides to Informatica MDM SaaS"
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--base-url", default=os.environ.get("IDMC_BASE_URL"))
    args = parser.parse_args()

    configs = load_yaml_files(args.config)
    all_valid = True
    for cfg in configs:
        errors = validate_config(cfg)
        if errors:
            for err in errors:
                logger.error("  - %s", err)
            all_valid = False

    if not all_valid:
        sys.exit(1)
    if args.validate_only:
        logger.info("All trust configs valid")
        return

    client = IDMCClient(base_url=args.base_url, dry_run=args.dry_run)
    totals = {"applied": 0, "error": 0}
    for cfg in configs:
        r = apply_trust_overrides(client, cfg)
        for k, v in r.items():
            totals[k] += v

    logger.info("Done — applied: %d  errors: %d", totals["applied"], totals["error"])
    if totals["error"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()

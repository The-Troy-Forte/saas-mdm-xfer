"""
apply_source_systems.py
-----------------------
Reads source system definitions from YAML and upserts them into
Informatica MDM SaaS via the IDMC REST API.

Supports:
  - Creating new source systems
  - Updating existing source systems (matched by source code)
  - Field-level trust score configuration per source
  - XREF key registration
  - Dry-run mode (no writes)

Usage:
  python apply_source_systems.py --config source_systems/facets_membership.yaml
  python apply_source_systems.py --config source_systems/         # all files in dir
  python apply_source_systems.py --config source_systems/ --dry-run
  python apply_source_systems.py --config source_systems/ --validate-only

YAML schema (see examples/source_system.yaml for full example):
  name: FACETS_MEMBERSHIP
  code: FACETS_MBR
  description: Medica Facets membership and enrollment system
  trust_default: 82
  fields:
    - mdm_field: firstName
      source_field: FIRST_NM
      trust: 82
  xref:
    source_id_field: MBR_ID
    mdm_xref_key: FACETS_MBR_ID
"""

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

from idmc_client import IDMCClient, IDMCError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# IDMC API paths
SOURCE_SYSTEM_LIST = "/mds/rest/v1/sourceSystem"
SOURCE_SYSTEM_BY_CODE = "/mds/rest/v1/sourceSystem/{code}"
FIELD_TRUST_PATH = "/mds/rest/v1/sourceSystem/{code}/fieldTrust"
XREF_CONFIG_PATH = "/mds/rest/v1/sourceSystem/{code}/xref"


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------
def load_yaml_files(config_path: str) -> List[Dict]:
    path = Path(config_path)
    files = []
    if path.is_dir():
        files = sorted(path.glob("*.yaml")) + sorted(path.glob("*.yml"))
    elif path.is_file():
        files = [path]
    else:
        raise FileNotFoundError(f"Config path not found: {config_path}")

    configs = []
    for f in files:
        with open(f) as fh:
            data = yaml.safe_load(fh)
            if data:
                data["_source_file"] = str(f)
                configs.append(data)
    logger.info("Loaded %d source system config(s)", len(configs))
    return configs


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
REQUIRED_KEYS = {"name", "code", "trust_default"}

def validate_config(config: Dict) -> List[str]:
    errors = []
    missing = REQUIRED_KEYS - set(config.keys())
    if missing:
        errors.append(f"Missing required keys: {missing}")
    trust = config.get("trust_default")
    if trust is not None and not (0 <= int(trust) <= 100):
        errors.append(f"trust_default must be 0–100, got {trust}")
    for field in config.get("fields", []):
        if "mdm_field" not in field:
            errors.append(f"Field entry missing 'mdm_field': {field}")
        if "source_field" not in field:
            errors.append(f"Field entry missing 'source_field': {field}")
        ft = field.get("trust")
        if ft is not None and not (0 <= int(ft) <= 100):
            errors.append(f"Field trust must be 0–100 for {field.get('mdm_field')}")
    return errors


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------
def get_existing_source_systems(client: IDMCClient) -> Dict[str, Any]:
    """Return dict of {code: source_system_object}."""
    try:
        systems = client.list_all(SOURCE_SYSTEM_LIST)
        return {s["sourceSystemCode"]: s for s in systems}
    except IDMCError as e:
        logger.error("Failed to fetch existing source systems: %s", e)
        return {}


def build_source_system_payload(config: Dict) -> Dict:
    return {
        "sourceSystemName": config["name"],
        "sourceSystemCode": config["code"],
        "description": config.get("description", ""),
        "trustScore": int(config["trust_default"]),
        "status": config.get("status", "ACTIVE"),
    }


def build_field_trust_payload(config: Dict) -> List[Dict]:
    return [
        {
            "fieldName": f["mdm_field"],
            "sourceFieldName": f["source_field"],
            "trustScore": int(f.get("trust", config["trust_default"])),
            "dataFormat": f.get("format", ""),
            "nullHandling": f.get("null_handling", "PRESERVE"),
            "pii": f.get("pii", False),
        }
        for f in config.get("fields", [])
    ]


def build_xref_payload(config: Dict) -> Dict:
    xref = config.get("xref", {})
    return {
        "sourceIdField": xref.get("source_id_field", ""),
        "mdmXrefKey": xref.get("mdm_xref_key", ""),
    }


# ---------------------------------------------------------------------------
# Upsert logic
# ---------------------------------------------------------------------------
def upsert_source_system(client: IDMCClient, config: Dict,
                          existing: Dict[str, Any]) -> str:
    """
    Create or update a source system.
    Returns 'created', 'updated', or 'skipped'.
    """
    code = config["code"]
    payload = build_source_system_payload(config)

    if code in existing:
        existing_id = existing[code].get("id") or existing[code].get("sourceSystemId")
        path = SOURCE_SYSTEM_BY_CODE.format(code=code)
        logger.info("Updating source system: %s (%s)", config["name"], code)
        try:
            client.put(path, payload)
            action = "updated"
        except IDMCError as e:
            logger.error("Failed to update %s: %s", code, e)
            return "error"
    else:
        logger.info("Creating source system: %s (%s)", config["name"], code)
        try:
            client.post(SOURCE_SYSTEM_LIST, payload)
            action = "created"
        except IDMCError as e:
            logger.error("Failed to create %s: %s", code, e)
            return "error"

    # Apply field-level trust
    fields = config.get("fields", [])
    if fields:
        ft_path = FIELD_TRUST_PATH.format(code=code)
        ft_payload = build_field_trust_payload(config)
        logger.info("  Applying %d field trust mappings for %s", len(fields), code)
        try:
            client.put(ft_path, {"fields": ft_payload})
        except IDMCError as e:
            logger.warning("  Field trust update failed for %s: %s", code, e)

    # Apply XREF config
    if config.get("xref"):
        xref_path = XREF_CONFIG_PATH.format(code=code)
        xref_payload = build_xref_payload(config)
        logger.info("  Applying XREF config for %s", code)
        try:
            client.put(xref_path, xref_payload)
        except IDMCError as e:
            logger.warning("  XREF config failed for %s: %s", code, e)

    return action


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Upsert Informatica MDM SaaS source systems from YAML"
    )
    parser.add_argument("--config", required=True,
                        help="Path to a YAML file or directory of YAML files")
    parser.add_argument("--dry-run", action="store_true",
                        help="Validate and preview changes without writing")
    parser.add_argument("--validate-only", action="store_true",
                        help="Validate YAML schema only — no API calls")
    parser.add_argument("--base-url", default=os.environ.get("IDMC_BASE_URL"),
                        help="IDMC base URL (overrides IDMC_BASE_URL env var)")
    args = parser.parse_args()

    configs = load_yaml_files(args.config)
    if not configs:
        logger.error("No YAML configs found at: %s", args.config)
        sys.exit(1)

    # Validate all configs first
    all_valid = True
    for cfg in configs:
        errors = validate_config(cfg)
        if errors:
            logger.error("Validation errors in %s:", cfg.get("_source_file", "?"))
            for err in errors:
                logger.error("  - %s", err)
            all_valid = False
        else:
            logger.info("  ✓ %s validated OK", cfg.get("code", "?"))

    if not all_valid:
        logger.error("Validation failed — aborting")
        sys.exit(1)

    if args.validate_only:
        logger.info("Validate-only mode — all configs valid, exiting")
        return

    client = IDMCClient(
        base_url=args.base_url,
        dry_run=args.dry_run,
    )

    existing = get_existing_source_systems(client)
    logger.info("Found %d existing source systems in IDMC", len(existing))

    results = {"created": 0, "updated": 0, "error": 0}
    for cfg in configs:
        action = upsert_source_system(client, cfg, existing)
        results[action] = results.get(action, 0) + 1

    logger.info(
        "Done — created: %d  updated: %d  errors: %d",
        results["created"], results["updated"], results["error"],
    )
    if results["error"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()

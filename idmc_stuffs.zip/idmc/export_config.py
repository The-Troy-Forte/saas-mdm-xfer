"""
export_config.py
----------------
Exports current Informatica MDM SaaS configuration state to YAML files.
Used for drift detection — compare exported state against the repo's
YAML configs to identify manual changes made directly in the IDMC UI.

Usage:
  python export_config.py --output-dir snapshots/
  python export_config.py --output-dir snapshots/ --diff-against config/
"""

import argparse
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

import yaml

from idmc_client import IDMCClient, IDMCError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

SOURCE_SYSTEM_LIST = "/mds/rest/v1/sourceSystem"
MATCH_RULE_LIST    = "/mds/rest/v1/matchRule"
TRUST_CONFIG_LIST  = "/mds/rest/v1/trustConfig"


def export_source_systems(client: IDMCClient) -> List[Dict]:
    logger.info("Exporting source systems...")
    try:
        return client.list_all(SOURCE_SYSTEM_LIST)
    except IDMCError as e:
        logger.error("Failed to export source systems: %s", e)
        return []


def export_match_rules(client: IDMCClient) -> List[Dict]:
    logger.info("Exporting match rules...")
    try:
        return client.list_all(MATCH_RULE_LIST)
    except IDMCError as e:
        logger.error("Failed to export match rules: %s", e)
        return []


def export_trust_config(client: IDMCClient) -> List[Dict]:
    logger.info("Exporting trust configuration...")
    try:
        return client.list_all(TRUST_CONFIG_LIST)
    except IDMCError as e:
        logger.error("Failed to export trust config: %s", e)
        return []


def write_snapshot(output_dir: str, data: Dict) -> Path:
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    snapshot_path = out / f"idmc_snapshot_{ts}.yaml"
    with open(snapshot_path, "w") as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=True)
    logger.info("Snapshot written: %s", snapshot_path)
    return snapshot_path


def diff_snapshot(snapshot: Dict, config_dir: str) -> List[str]:
    """
    Simple drift detection: compare snapshot source system codes
    and match rule names against the config directory YAML files.
    Returns list of drift findings.
    """
    findings = []
    config_path = Path(config_dir)

    # Collect codes defined in repo YAML
    repo_codes = set()
    for f in config_path.rglob("*.yaml"):
        with open(f) as fh:
            data = yaml.safe_load(fh) or {}
        if "code" in data:
            repo_codes.add(data["code"])

    # Compare against snapshot
    live_codes = {s.get("sourceSystemCode") for s in snapshot.get("source_systems", [])}
    for code in live_codes - repo_codes:
        findings.append(f"DRIFT: Source system '{code}' exists in IDMC but not in repo config")
    for code in repo_codes - live_codes:
        findings.append(f"MISSING: Source system '{code}' is in repo config but not in IDMC")

    return findings


def main():
    parser = argparse.ArgumentParser(
        description="Export Informatica MDM SaaS config state to YAML"
    )
    parser.add_argument("--output-dir", default="snapshots",
                        help="Directory to write snapshot YAML (default: snapshots/)")
    parser.add_argument("--diff-against", default=None,
                        help="Config directory to diff snapshot against for drift detection")
    parser.add_argument("--base-url", default=os.environ.get("IDMC_BASE_URL"))
    args = parser.parse_args()

    client = IDMCClient(base_url=args.base_url)

    snapshot = {
        "exported_at": datetime.utcnow().isoformat() + "Z",
        "source_systems": export_source_systems(client),
        "match_rules": export_match_rules(client),
        "trust_config": export_trust_config(client),
    }

    snapshot_path = write_snapshot(args.output_dir, snapshot)
    logger.info(
        "Exported: %d source systems, %d match rules, %d trust configs",
        len(snapshot["source_systems"]),
        len(snapshot["match_rules"]),
        len(snapshot["trust_config"]),
    )

    if args.diff_against:
        findings = diff_snapshot(snapshot, args.diff_against)
        if findings:
            logger.warning("Drift detected:")
            for f in findings:
                logger.warning("  %s", f)
            sys.exit(2)  # exit 2 = drift found (not an error, but noteworthy)
        else:
            logger.info("No drift detected — IDMC config matches repo")


if __name__ == "__main__":
    main()

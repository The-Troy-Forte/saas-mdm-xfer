"""
idmc_client.py
--------------
Shared Informatica MDM SaaS (IDMC) REST client.

Handles:
  - Authentication via OAuth2 client credentials (IDMC v3 auth)
  - Automatic token refresh on 401
  - Retry with exponential backoff on 429 / 5xx
  - All base REST operations used by the apply scripts

Environment variables (or pass via IDMCClient constructor):
  IDMC_BASE_URL       e.g. https://dm-us.informaticacloud.com
  IDMC_CLIENT_ID      OAuth2 client ID
  IDMC_CLIENT_SECRET  OAuth2 client secret
  IDMC_POD_URL        Pod-specific base URL returned after login
                      (optional — resolved automatically on first auth)

Usage:
  from idmc_client import IDMCClient
  client = IDMCClient()
  result = client.get("/mds/rest/v1/sourceSystem")
"""

import os
import time
import logging
from typing import Any, Dict, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Retry strategy — back off on rate-limit and server errors
# ---------------------------------------------------------------------------
def _build_session(retries: int = 3, backoff: float = 1.0) -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


# ---------------------------------------------------------------------------
# IDMCClient
# ---------------------------------------------------------------------------
class IDMCClient:
    """
    Thin wrapper around the Informatica MDM SaaS REST API.

    Authentication uses IDMC v3 OAuth2 (client_credentials grant).
    The client automatically refreshes the bearer token on expiry.
    """

    AUTH_PATH = "/ma/api/v2/user/login"          # legacy session login
    OAUTH_PATH = "/identity-service/api/v1/oauth/token"  # OAuth2 token endpoint

    def __init__(
        self,
        base_url: Optional[str] = None,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        timeout: int = 30,
        dry_run: bool = False,
    ):
        self.base_url = (base_url or os.environ["IDMC_BASE_URL"]).rstrip("/")
        self.client_id = client_id or os.environ["IDMC_CLIENT_ID"]
        self.client_secret = client_secret or os.environ["IDMC_CLIENT_SECRET"]
        self.timeout = timeout
        self.dry_run = dry_run

        self._session = _build_session()
        self._token: Optional[str] = None
        self._token_expiry: float = 0.0
        self._pod_url: Optional[str] = os.environ.get("IDMC_POD_URL")

        if self.dry_run:
            logger.info("[DRY RUN] IDMCClient initialised — no writes will be made")

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------
    def _authenticate(self) -> None:
        """Obtain a bearer token via OAuth2 client credentials."""
        url = f"{self.base_url}{self.OAUTH_PATH}"
        payload = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        resp = self._session.post(url, data=payload, timeout=self.timeout)
        if not resp.ok:
            raise RuntimeError(
                f"IDMC authentication failed [{resp.status_code}]: {resp.text}"
            )
        data = resp.json()
        self._token = data["access_token"]
        # expires_in is in seconds; buffer 60 s
        self._token_expiry = time.time() + data.get("expires_in", 3600) - 60
        # Some IDMC pods return a serverUrl for subsequent calls
        if "serverUrl" in data:
            self._pod_url = data["serverUrl"].rstrip("/")
        logger.debug("IDMC token acquired; expires in %s s", data.get("expires_in"))

    def _ensure_token(self) -> None:
        if self._token is None or time.time() >= self._token_expiry:
            self._authenticate()

    def _headers(self) -> Dict[str, str]:
        self._ensure_token()
        return {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def _url(self, path: str) -> str:
        base = self._pod_url or self.base_url
        return f"{base}/{path.lstrip('/')}"

    # ------------------------------------------------------------------
    # Core HTTP verbs
    # ------------------------------------------------------------------
    def _request(
        self,
        method: str,
        path: str,
        payload: Optional[Dict] = None,
        params: Optional[Dict] = None,
    ) -> requests.Response:
        url = self._url(path)
        headers = self._headers()

        if self.dry_run and method.upper() in ("POST", "PUT", "PATCH", "DELETE"):
            logger.info("[DRY RUN] %s %s payload=%s", method.upper(), url, payload)
            # Return a mock 200 response
            mock = requests.Response()
            mock.status_code = 200
            mock._content = b'{"dryRun": true}'
            return mock

        resp = self._session.request(
            method,
            url,
            headers=headers,
            json=payload,
            params=params,
            timeout=self.timeout,
        )

        # Retry once on 401 (token may have been revoked externally)
        if resp.status_code == 401:
            logger.warning("Received 401 — refreshing token and retrying")
            self._token = None
            headers = self._headers()
            resp = self._session.request(
                method, url, headers=headers,
                json=payload, params=params, timeout=self.timeout,
            )

        if not resp.ok:
            raise IDMCError(method, url, resp.status_code, resp.text)

        return resp

    def get(self, path: str, params: Optional[Dict] = None) -> Any:
        return self._request("GET", path, params=params).json()

    def post(self, path: str, payload: Dict) -> Any:
        return self._request("POST", path, payload=payload).json()

    def put(self, path: str, payload: Dict) -> Any:
        return self._request("PUT", path, payload=payload).json()

    def patch(self, path: str, payload: Dict) -> Any:
        return self._request("PATCH", path, payload=payload).json()

    def delete(self, path: str) -> None:
        self._request("DELETE", path)

    # ------------------------------------------------------------------
    # Convenience: paginated list
    # ------------------------------------------------------------------
    def list_all(self, path: str, page_size: int = 100) -> list:
        """Fetch all pages from a paginated IDMC endpoint."""
        results = []
        offset = 0
        while True:
            page = self.get(path, params={"limit": page_size, "offset": offset})
            items = page if isinstance(page, list) else page.get("items", [])
            results.extend(items)
            if len(items) < page_size:
                break
            offset += page_size
        return results


# ---------------------------------------------------------------------------
# Custom exception
# ---------------------------------------------------------------------------
class IDMCError(Exception):
    def __init__(self, method: str, url: str, status: int, body: str):
        self.method = method
        self.url = url
        self.status = status
        self.body = body
        super().__init__(f"IDMC {method} {url} returned {status}: {body[:400]}")

# Informatica MDM SaaS — Python Config & Data Scripts

YAML-driven configuration management and person record upsert scripts
for Informatica MDM SaaS (IDMC) at Medica.

---

## Setup

```bash
pip install -r requirements.txt
```

Set environment variables (or use Azure Key Vault via your CI/CD pipeline):

```bash
export IDMC_BASE_URL=https://dm-us.informaticacloud.com
export IDMC_CLIENT_ID=your-client-id
export IDMC_CLIENT_SECRET=your-client-secret
```

---

## Scripts

| Script | Purpose |
|---|---|
| `idmc_client.py` | Shared REST client — auth, retry, token refresh |
| `apply_source_systems.py` | Register / update source systems from YAML |
| `apply_match_rules.py` | Create / update match rules from YAML |
| `apply_trust_config.py` | Apply field-level trust overrides from YAML |
| `upsert_person_records.py` | Insert / update person records from YAML |
| `export_config.py` | Export current IDMC state for drift detection |

---

## apply_source_systems.py

Register or update Medica source systems (Facets, Epic, Workday, etc.)
into Informatica MDM SaaS.

```bash
# Apply a single source system
python apply_source_systems.py --config examples/source_systems/facets_membership.yaml

# Apply all source systems in a directory
python apply_source_systems.py --config examples/source_systems/

# Dry run — preview without writing
python apply_source_systems.py --config examples/source_systems/ --dry-run

# Validate YAML schema only
python apply_source_systems.py --config examples/source_systems/ --validate-only
```

---

## apply_match_rules.py

Create or update match rules (exact and probabilistic) for each
person entity type.

```bash
python apply_match_rules.py --config examples/match_rules/member_rules.yaml
python apply_match_rules.py --config examples/match_rules/ --dry-run
```

---

## apply_trust_config.py

Apply field-level trust score overrides. Trust scores control which
source system's value wins when multiple sources conflict.

```bash
python apply_trust_config.py --config examples/trust_config/field_trust_overrides.yaml
python apply_trust_config.py --config examples/trust_config/ --dry-run
```

---

## upsert_person_records.py

Insert new person records and update existing ones. Performs XREF
lookup to determine insert vs update automatically.

```bash
# Upsert member records
python upsert_person_records.py --config examples/records/members.yaml

# Filter to a specific source system
python upsert_person_records.py --config examples/records/ --source FACETS_MBR

# Custom batch size
python upsert_person_records.py --config examples/records/ --batch-size 50

# Validate records only
python upsert_person_records.py --config examples/records/ --validate-only
```

### Person types supported

| YAML person_type | Description |
|---|---|
| `member` | Health plan members / enrollees |
| `provider` | Physicians, facilities, practitioners |
| `employee` | Medica employees |
| `broker` | Brokers and agents |
| `employer` | Employer groups |

---

## export_config.py

Export the current IDMC config state to a timestamped YAML snapshot.
Optionally diff against the repo config directory for drift detection.

```bash
# Export snapshot
python export_config.py --output-dir snapshots/

# Export and check for drift against config directory
python export_config.py --output-dir snapshots/ --diff-against examples/source_systems/
```

Exit code `2` indicates drift was detected (not a failure, but noteworthy).

---

## GitHub Actions Integration

```yaml
# .github/workflows/apply_mdm_config.yml
name: Apply MDM Configuration

on:
  pull_request:
    paths: ['source_systems/**', 'match_rules/**', 'trust_config/**']
  push:
    branches: [main]
    paths: ['source_systems/**', 'match_rules/**', 'trust_config/**']

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install -r requirements.txt
      - run: python apply_source_systems.py --config source_systems/ --validate-only
      - run: python apply_match_rules.py --config match_rules/ --validate-only
      - run: python apply_trust_config.py --config trust_config/ --validate-only
    env:
      IDMC_BASE_URL: ${{ secrets.IDMC_BASE_URL }}
      IDMC_CLIENT_ID: ${{ secrets.IDMC_SANDBOX_CLIENT_ID }}
      IDMC_CLIENT_SECRET: ${{ secrets.IDMC_SANDBOX_CLIENT_SECRET }}

  apply:
    if: github.ref == 'refs/heads/main'
    needs: validate
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install -r requirements.txt
      - run: python apply_source_systems.py --config source_systems/
      - run: python apply_match_rules.py --config match_rules/
      - run: python apply_trust_config.py --config trust_config/
      - run: python export_config.py --output-dir snapshots/ --diff-against source_systems/
      - uses: stefanzweifel/git-auto-commit-action@v5
        with:
          commit_message: "chore: IDMC config snapshot post-apply"
          file_pattern: snapshots/*.yaml
    env:
      IDMC_BASE_URL: ${{ secrets.IDMC_BASE_URL }}
      IDMC_CLIENT_ID: ${{ secrets.IDMC_PROD_CLIENT_ID }}
      IDMC_CLIENT_SECRET: ${{ secrets.IDMC_PROD_CLIENT_SECRET }}
```

---

## Directory structure

```
idmc/
  idmc_client.py              Shared REST client
  apply_source_systems.py     Source system upserts
  apply_match_rules.py        Match rule upserts
  apply_trust_config.py       Trust score overrides
  upsert_person_records.py    Person record inserts/updates
  export_config.py            Config snapshot + drift detection
  requirements.txt
  examples/
    source_systems/
      facets_membership.yaml
      epic_clinical.yaml       (add per source)
      workday_hr.yaml
    match_rules/
      member_rules.yaml
      provider_rules.yaml      (add per person type)
    trust_config/
      field_trust_overrides.yaml
    records/
      members.yaml
      providers.yaml           (add per person type)
```

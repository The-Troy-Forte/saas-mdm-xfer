"""
apply_match_rules.py
--------------------
Reads match rule definitions from YAML and upserts them into
Informatica MDM SaaS via the IDMC REST API.

Supports:
  - Exact match rules
  - Probabilistic (fuzzy) match rules
  - Rule enable/disable
  - Per-entity-type rule sets (member, provider, employee, broker, employer)

Usage:
  python apply_match_rules.py --config match_rules/member_rules.yaml
  python apply_match_rules.py --config match_rules/
  python apply_match_rules.py --config match_rules/ --dry-run

YAML schema (see examples/match_rules.yaml for full example):
  entity: Person
  person_type: member
  rules:
    - name: member_ssn_exact
      type: exact
      fields: [nationalId]
      weight: 100
      enabled: true
    - name: member_name_dob_fuzzy
      type: probabilistic
      fields: [firstName, lastName, dateOfBirth]
      threshold: 85
      weight: 80
      enabled: true
"""

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List

import yaml

from idmc_client import IDMCClient, IDMCError

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

MATCH_RULE_LIST = "/mds/rest/v1/matchRule"
MATCH_RULE_BY_NAME = "/mds/rest/v1/matchRule/{name}"


# ---------------------------------------------------------------------------
# YAML loading
# ---------------------------------------------------------------------------
def load_yaml_files(config_path: str) -> List[Dict]:
    path = Path(config_path)
    files = sorted(path.glob("*.yaml")) + sorted(path.glob("*.yml")) \
        if path.is_dir() else [path]
    configs = []
    for f in files:
        with open(f) as fh:
            data = yaml.safe_load(fh)
            if data:
                data["_source_file"] = str(f)
                configs.append(data)
    logger.info("Loaded %d match rule config(s)", len(configs))
    return configs


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
VALID_TYPES = {"exact", "probabilistic", "fuzzy"}

def validate_config(config: Dict) -> List[str]:
    errors = []
    if "entity" not in config:
        errors.append("Missing 'entity' (e.g. Person)")
    for rule in config.get("rules", []):
        if "name" not in rule:
            errors.append(f"Rule missing 'name': {rule}")
        rt = rule.get("type", "").lower()
        if rt not in VALID_TYPES:
            errors.append(f"Rule '{rule.get('name')}' has invalid type '{rt}'")
        if not rule.get("fields"):
            errors.append(f"Rule '{rule.get('name')}' has no fields")
        if rt in ("probabilistic", "fuzzy"):
            t = rule.get("threshold")
            if t is None:
                errors.append(f"Probabilistic rule '{rule.get('name')}' missing threshold")
            elif not (0 <= int(t) <= 100):
                errors.append(f"Threshold must be 0–100 for '{rule.get('name')}'")
    return errors


# ---------------------------------------------------------------------------
# Payload builders
# ---------------------------------------------------------------------------
def build_rule_payload(rule: Dict, entity: str) -> Dict:
    rule_type = rule["type"].lower()
    payload = {
        "ruleName": rule["name"],
        "entityType": entity,
        "matchType": "EXACT" if rule_type == "exact" else "PROBABILISTIC",
        "matchFields": [
            {"fieldName": f, "matchAlgorithm": rule.get("algorithm", "EXACT"
                if rule_type == "exact" else "JARO_WINKLER")}
            for f in rule["fields"]
        ],
        "weight": rule.get("weight", 100),
        "enabled": rule.get("enabled", True),
        "personType": rule.get("person_type", ""),
    }
    if rule_type in ("probabilistic", "fuzzy"):
        payload["threshold"] = rule.get("threshold", 85)
    return payload


# ---------------------------------------------------------------------------
# Upsert
# ---------------------------------------------------------------------------
def get_existing_rules(client: IDMCClient) -> Dict[str, Any]:
    try:
        rules = client.list_all(MATCH_RULE_LIST)
        return {r["ruleName"]: r for r in rules}
    except IDMCError as e:
        logger.error("Failed to fetch existing match rules: %s", e)
        return {}


def upsert_rule(client: IDMCClient, rule: Dict, entity: str,
                existing: Dict[str, Any]) -> str:
    name = rule["name"]
    payload = build_rule_payload(rule, entity)

    if name in existing:
        logger.info("  Updating match rule: %s", name)
        try:
            client.put(MATCH_RULE_BY_NAME.format(name=name), payload)
            return "updated"
        except IDMCError as e:
            logger.error("  Failed to update rule %s: %s", name, e)
            return "error"
    else:
        logger.info("  Creating match rule: %s", name)
        try:
            client.post(MATCH_RULE_LIST, payload)
            return "created"
        except IDMCError as e:
            logger.error("  Failed to create rule %s: %s", name, e)
            return "error"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Upsert Informatica MDM SaaS match rules from YAML"
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--base-url", default=os.environ.get("IDMC_BASE_URL"))
    args = parser.parse_args()

    configs = load_yaml_files(args.config)

    all_valid = True
    for cfg in configs:
        errors = validate_config(cfg)
        if errors:
            logger.error("Validation errors in %s:", cfg.get("_source_file", "?"))
            for err in errors:
                logger.error("  - %s", err)
            all_valid = False

    if not all_valid:
        sys.exit(1)
    if args.validate_only:
        logger.info("All configs valid")
        return

    client = IDMCClient(base_url=args.base_url, dry_run=args.dry_run)
    existing = get_existing_rules(client)

    results = {"created": 0, "updated": 0, "error": 0}
    for cfg in configs:
        entity = cfg.get("entity", "Person")
        logger.info("Processing rules for entity=%s (%s)",
                    entity, cfg.get("_source_file", ""))
        for rule in cfg.get("rules", []):
            action = upsert_rule(client, rule, entity, existing)
            results[action] = results.get(action, 0) + 1

    logger.info("Done — created: %d  updated: %d  errors: %d",
                results["created"], results["updated"], results["error"])
    if results["error"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
